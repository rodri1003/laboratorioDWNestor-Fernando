import express from "express"
import cors from "cors"
import UserRoute from "./routes/UserRoute.js"

//well create our server
const app = express()

//Become json response
app.use(express.json())

app.use(cors())

//define a port
const PORT = process.env.port ?? 2000

//call the routes
app.use(UserRoute)


//running the server
app.listen(PORT, ()=>{
    console.log(`Server running at the port ${PORT}`);
})

