import UserRepository from "../repository/UserRepository.js"

export const UserController={
    
    async register(req, res){
        const {username,password}=req.body
        console.log(username,password)
        try {
            const responseDate=UserRepository.create({
                username,
                password
            })           
            res.send({
                status:true,
                id:responseDate,
                message:"Register succesfull"
            })
        }catch(error){
            res.send({
                status:false,
                message:error.message
            })
        }
    },

    async login(req, res){   
        try {
            const responseDate=UserRepository({

            })
            res.send({
                status:true,
                message:"login succesfull",
                data:responseDate
            })
            }catch(error){
            res.send({
                status:false,
                message:error.message
            })
        }
    }

}
